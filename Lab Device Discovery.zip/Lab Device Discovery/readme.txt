# IoT Device Penetration Testing Lab

## Project Overview
This project demonstrates security testing of IoT devices in a controlled lab environment.

## Objectives
- Discover IoT devices on a network
- Analyze device communication
- Extract and analyze firmware
- Identify security vulnerabilities

## Tools Used
- Kali Linux
- Nmap
- Wireshark
- Binwalk
- Ghidra
- Metasploit

## Lab Architecture
(Add architecture diagram here)

## Experiments
1. Device Discovery
2. Traffic Analysis
3. Firmware Analysis
4. Vulnerability Testing

## Results
Summary of vulnerabilities discovered in IoT devices.

## Disclaimer
This project is for educational purposes only.